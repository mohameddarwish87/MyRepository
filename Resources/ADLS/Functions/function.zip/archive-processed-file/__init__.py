#***********************************************************************************************************************
#**  Name:                   archive-processed-file Azure Function
#**  Desc:                   This function is responsible to move file from landing to corresponding path in raw zone with date partition
#**                          filename with its path and account name is passed as HTTP get request to the function
#**                          Ex: https://intergen-data-mdp-function-dev.azurewebsites.net/api/archive-processed-file?filename=AdventureWorks/Person/Person/Person1.parquet&storage_account=intergendatamdpadlsdev
#**  Auth:                   J Grata
#**  Date:                   02/11/2021
#**
#**  Change History
#**  --------------
#**  No.     Date            Author              Description
#**  ---     ----------      -----------         ---------------------------------------------------------------
#**  1       01/11/2021      J Grata             Original Version
#**  2       09/12/2021      M Darwish           using KV to access accountkey, remove archived from raw landing path, changing format of UTC for filename, removing for loop to get metadata


import logging
import azure.functions as func
import pandas as pd
import os
from datetime import datetime
from azure.storage.blob import BlobServiceClient, ContainerClient
from azure.storage.filedatalake import (
DataLakeServiceClient,
)
import os, uuid, sys
from azure.storage.filedatalake import DataLakeServiceClient
from azure.core._match_conditions import MatchConditions
from azure.storage.filedatalake._models import ContentSettings
from azure.keyvault.secrets import SecretClient
from azure.identity import DefaultAzureCredential

def main(req: func.HttpRequest) -> func.HttpResponse:
    KVUri = f"https://intergen-mdp-keyvault.vault.azure.net/"
    credential1 = DefaultAzureCredential() #will use managed identity enabled to authenticate azure function to access KV
    client = SecretClient(vault_url=KVUri, credential=credential1)#creating secret client to access KV to read credential of service principal
    storage_account_key = client.get_secret('intergen-adls-accesskey')

    #GET PASSED  PARAMETERS

    filename = req.params.get('filename')

    if not filename:
        try:
            req_body = req.get_json()
        except ValueError:
            pass
        else:
            filename = req_body.get('filename')
    storage_account = req.params.get('storage_account') 
    if not storage_account:
        try:
            req_body = req.get_json()
        except ValueError:
            pass
           
        else:
            storage_account = req_body.get('storage_account')

    account_url=f"https://{storage_account}.dfs.core.windows.net"
    blob_url=f"https://{storage_account}.blob.core.windows.net"
        
    #ACCESS BL
    conn_str="DefaultEndpointsProtocol=http;AccountName={};AccountKey={};BlobEndpoint={}/;".format(storage_account,storage_account_key.value,blob_url)
    container_name="landing"

    #GET METADATA FROM FILENAME
    date_partition = get_metadata(conn_str,container_name,filename)

    #Access storage account to move files
    initialize_datalakeservice(account_url, storage_account_key.value)
    move_directory(filename, container_name, date_partition)

    if filename and storage_account:
        return func.HttpResponse(f"Successfully archived {filename}. This HTTP triggered function executed successfully.")
    else:
        return func.HttpResponse(
             "This HTTP triggered function execution failed. Please pass a \'filename\' and a \'storage_account\' name in the query string or in the request body.",
             status_code=404)

def get_metadata(conn_str,container_name,filename):
    container_client=ContainerClient.from_connection_string(conn_str,container_name)
    blob_service_client = BlobServiceClient.from_connection_string(conn_str)
    SourceName1 = filename.rsplit('/')
    SourceName1 = SourceName1[:-1]
    SourceName1 = "/".join(SourceName1)

    blob_metadata = {}
    blob_client = blob_service_client.get_blob_client(container=container_name, blob=SourceName1)
    a = blob_client.get_blob_properties()
    
    if 'datepartitionpath' in a.metadata:
        blob_metadata = a.metadata
    return blob_metadata['datepartitionpath']

def initialize_datalakeservice(account_url, storage_account_key):
    
    try:  
        global service_client

        service_client = DataLakeServiceClient(account_url, credential=storage_account_key)
        logging.info('Successfully connected')
    
    except Exception as e:
        print(e)

def move_directory(filename, container_name, date_partition):
    current_datetime = datetime.utcnow()
    output_date = current_datetime
    output_date = str(output_date).replace(' ', 'T')
    output_date = output_date + 'Z'
    filename2 = filename.rsplit('/')
    filename2 = filename2[-1]
    filename2 = filename2.rsplit('.')
    ext = '.'+filename2[-1]
    filename2 = filename2[0]

    try:
        file_system_client = service_client.get_file_system_client(container_name)
        directory_client = file_system_client.get_directory_client(filename)
        new_dir_name = 'raw/'
        new_dir_name += create_directory(filename, date_partition, current_datetime)
        new_dir_name += filename2+'_'+output_date+ext
        directory_client.rename_directory(new_dir_name)
        logging.info(f'succesfully moved file: {new_dir_name}')
    except Exception as e:
     print(e)
     raise

def create_directory(filename, date_partition, current_datetime):
    file_system_client = service_client.get_file_system_client('raw')
    new_directory = ''
    
    #CREATE DIRECTORY FOR SUBFOLDER IF NOT EXIST
    try:
        logging.info('creating new directory!')
        new_directory += filename[0:filename.rindex('/')] + '/'
        file_system_client.create_directory(new_directory)
        logging.info('successfully created new directory!')
    except:
        logging.info('no directory created')

    #CREATE DATE PARTITIONS
    partitions = date_partition.split('/')

    for partition in partitions:
        if('Y' in partition):
            new_directory += str(current_datetime.year)+'/'
        if('M' in partition):
            new_directory += str(current_datetime.month)+'/'
        if('D' in partition):
            new_directory += str(current_datetime.day)+'/'
        if('T' in partition):
            new_directory += str(current_datetime.strftime('%H%M%S'))+'/'

    file_system_client.create_directory(new_directory)
    logging.info(f'succesfully created directory partition: {new_directory}')
    return new_directory
