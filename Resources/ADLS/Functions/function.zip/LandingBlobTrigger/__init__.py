#***********************************************************************************************************************
#**  Name:                   LandingToStagingBlob Azure Function
#**  Desc:                   This function is responsible to listen to any file arrive in landing zone, capture its parent folder metadata and 
#**                          call another function that will generate spark job that will run another python file which is responsible to write 
#**                          the file data to its corresponding path in staging zone in delta format
#**  Auth:                   M Darwish
#**  Date:                   03/12/2021
#**
#**  Change History
#**  --------------
#**  No.     Date            Author              Description
#**  ---     ----------      -----------         ---------------------------------------------------------------
#**  1       03/12/2021      M Darwish           Original Version
#**  2       06/12/2021      M Darwish           Removing the for loop that goes through list of blob of landing and pass directly blob based on myblob.name
#**  3       07/12/2021      M Darwish           generating metadata_file with name of file sourcename, schema name and utc timestamp

import logging
import azure.functions as func
from azure.keyvault.secrets import SecretClient
from azure.identity import DefaultAzureCredential
from azure.storage.blob import BlobServiceClient
from azure.identity import ClientSecretCredential 
import pandas as pd
from azure.synapse import SynapseClient
from azure.synapse.models import ExtendedLivyBatchRequest
from datetime import datetime

def main(myblob: func.InputStream):# Main function that will read the parent folder metadata of arrived file and generate it to JSON file then call another function that will start the spark job
    logging.info(f"Python blob trigger function processed blob \n"
                 f"Name: {myblob.name}\n"
                 f"Blob Size: {myblob.length} bytes")

    KVUri = f"https://intergen-mdp-keyvault.vault.azure.net/" # KV path to read credential of service principal

    credential1 = DefaultAzureCredential() #will use managed identity enabled to authenticate azure function to access KV
    client = SecretClient(vault_url=KVUri, credential=credential1)#creating secret client to access KV to read credential of service principal
    CLIENT_ID = client.get_secret('intergen-adls-clientid')#Reading Client ID of SP 
    CLIENT_SECRET = client.get_secret('intergen-adls-clientsecret')#Reading Client Secret of SP
    TENANT_ID = client.get_secret('intergen-adls-tenantid')#Reading Tenant ID of SP

    credential2 = ClientSecretCredential(client_id=CLIENT_ID.value,client_secret=CLIENT_SECRET.value,tenant_id=TENANT_ID.value)

    container_name = "landing"
    ACCOUNT_NAME = "intergendatamdpadlsdev"
    blob_service_client = BlobServiceClient("https://{}.blob.core.windows.net".format(ACCOUNT_NAME),credential=credential2)
    container_client = blob_service_client.get_container_client(container_name)
    
    txt = myblob.name
    txt = txt.rsplit('/')#convert the path into list with each folder as element in list and using / as separator (delimiter)
    FileName = txt[-1]#assigning last element of the list which is file name to the variable
    txt= txt[:-1] #delete the the filename.ext from folder path to get the parent folder so that we can fetch its metadata
    txt.pop(0) #delete 'landing' from the folder path as it is not required
    txt2 = txt #txt2 will hold source name in form of AdventureWorks_Person_Person to be used as name for metadata file
    txt = "/".join(txt)#creating path again without filename and 'landing using / as delimiter
    txt2 = "_".join(txt2)
    
    dat_txt = str(datetime.utcnow()) #dat_txt will hold the timestamp of metadata file creation that will be added to metadata file name
    dat_txt = dat_txt.rsplit('-')
    dat_txt = "_".join(dat_txt)
    dat_txt = dat_txt.rsplit(' ')
    dat_txt = "_".join(dat_txt)
    dat_txt = dat_txt.rsplit(':')
    dat_txt = "_".join(dat_txt)
    dat_txt = dat_txt.rsplit('.')
    dat_txt = dat_txt[:-1]
    dat_txt = "_".join(dat_txt)
    txt3 = txt2+'_'+'Metadata_'+dat_txt+'.json'
    storage_account_key = client.get_secret('intergen-adls-accesskey')#fetching account key from KV to be used to access the ADLS
    conn_str="DefaultEndpointsProtocol=http;AccountName="+ACCOUNT_NAME+";AccountKey=" \
           +storage_account_key.value+ \
           ";BlobEndpoint=https://{}.blob.core.windows.net/;".format(ACCOUNT_NAME)
    DataLakeCuratedURL = 'abfss://curated@{}.dfs.core.windows.net'.format(ACCOUNT_NAME)
    DataLakeSystemURL = 'abfss://system@{}.dfs.core.windows.net'.format(ACCOUNT_NAME)
    
    blob_client = blob_service_client.get_blob_client(container=container_name, blob=txt) #create blob client for the blob of where file is landed
    a = blob_client.get_blob_properties() #fetch the blob properties
    if (a.metadata['pushtostagingzone']): #if metadata 'pushtostagingzone' is true
           new_dict ={} #creating new empty dictionary
           new_dict["SourceName"] = txt #appending to empty dictionary source name (path of file landed without filename and 'landing')
           new_dict["FileName"] = FileName
           new_dict.update(a.metadata) #appending metadata dictionary to new_dict dictionary
           pdf = pd.DataFrame(new_dict.items()) #1)read metadata dict and create data frame from it and assign it to dataframe variable
           pdf = pdf.rename(columns={0: 'Metadata_title',1:'Metadata_value'})#renaming columns of DataFrame
           pdf = pdf.rename(index={0: "SourceName",1:"FileName",2:"businesskey1",3:"businesskey2",4:"businesskey3",5:"businesskey4",6:"partitionkey",7:"pushtostagingzone",8:"scd2flag",9:"watermarkcol",10:"hdi_isfolder"})#renaming teh rows of dataframe
           pdf.to_json(orient="records",path_or_buf = DataLakeSystemURL + '/' + 'Parameters/'+txt3, storage_options = {"account_name": "intergendatamdpadlsdev",'account_key' : storage_account_key.value,"connection_string": conn_str})#writing the metadata of parent folder in the JSON file in curated zone
           RunSparkJob(credential2,txt3)#calling the fucntion that will start the spark job
            

def RunSparkJob(credential: func.InputStream,metadata_file: func.InputStream):
#function that will create spark job that will call Python File that will move data of landing file into delta fomat in staging zone
    workspace_name = "intergen-data-mdp-synapse-dev"
    spark_pool_name = "Spark3MoreNodes"
    ACCOUNT_NAME = "intergendatamdpadlsdev"
    batch_id = 1
    job_name = "ConvertToDeltaInStaging"
    file = "abfss://system@{}.dfs.core.windows.net/Functions/ConvertToDelta.py".format(ACCOUNT_NAME)
    class_name = "Hello"
    args = ["abfss://system@{}.dfs.core.windows.net/Parameters/{}".format(ACCOUNT_NAME,metadata_file)]
    driver_memory = "4g"
    driver_cores = 4
    executor_memory = "4g"
    executor_cores = 4
    num_executors = 2
    synapse_client = SynapseClient(credential)
    spark_batch_operation = synapse_client.spark_batch
    livy_batch_request = ExtendedLivyBatchRequest(name=job_name, file=file, class_name=class_name, args=args, 
             driver_memory=driver_memory, driver_cores=driver_cores, executor_memory=executor_memory,
            executor_cores=executor_cores, num_executors=num_executors)

    spark_batch_operation.create(workspace_name, spark_pool_name, livy_batch_request) #creating spark job and passing to it job parameters

    
if __name__ == "__main__":
    main()

